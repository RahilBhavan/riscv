// Spike target for riscv-arch-test 3.x, following riscof-plugins/rv32/spike_simple/env/model_test.h.
#ifndef _COMPLIANCE_MODEL_H
#define _COMPLIANCE_MODEL_H
#define ALIGNMENT 2

#define RVMODEL_DATA_SECTION \
        .pushsection .tohost,"aw",@progbits; \
        .align 8; .global tohost; tohost: .dword 0; \
        .align 8; .global fromhost; fromhost: .dword 0; \
        .popsection;

#define RVMODEL_HALT \
  .global rvmodel_halt; rvmodel_halt: \
  li x1, 1; \
1: \
  sw x1, tohost, t2; \
  j 1b;

#define RVMODEL_BOOT

#define RVMODEL_DATA_BEGIN \
  RVMODEL_DATA_SECTION \
  .align ALIGNMENT; \
  .global begin_signature; begin_signature:

#define RVMODEL_DATA_END \
  .global end_signature; end_signature:

#define RVMODEL_IO_INIT
#define RVMODEL_IO_WRITE_STR(_R, _STR)
#define RVMODEL_IO_CHECK()
#define RVMODEL_IO_ASSERT_GPR_EQ(_S, _R, _I)
#define RVMODEL_IO_ASSERT_SFPR_EQ(_F, _R, _I)
#define RVMODEL_IO_ASSERT_DFPR_EQ(_D, _R, _I)
#define RVMODEL_SET_MSW_INT
#define RVMODEL_CLEAR_MSW_INT
#define RVMODEL_CLEAR_MTIMER_INT
#define RVMODEL_CLEAR_MEXT_INT
#endif
